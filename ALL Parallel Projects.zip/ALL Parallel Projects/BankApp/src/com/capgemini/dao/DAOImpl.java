package com.capgemini.dao;


import java.io.IOException;
import java.util.HashMap;
//import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
//import javax.persistence.Query;
//import javax.persistence.QueryHint;
import javax.persistence.TypedQuery;

import com.capgemini.bean.Holder;

public class DAOImpl implements DAO {
	
	static Map<Long,Holder> accmap = new HashMap<Long,Holder>();
	
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("JavaWithJpaPLP");
	
	EntityManager em=emf.createEntityManager();

	@Override
	public Holder addAccount(Holder c) {
		em.getTransaction().begin();
		Holder ob1= new Holder();
		ob1.setFirstname(c.getFirstname());
		ob1.setLastname(c.getLastname());
		ob1.setPhonenum(c.getPhonenum());
		ob1.setAadharnum(c.getAadharnum());
		ob1.setAccountnum(c.getAccountnum());
		ob1.setMoney(c.getMoney());
		em.persist(ob1);
		em.getTransaction().commit();
		System.out.println(" Successfully Added ");
	    return null;
	}

	@Override
	public Map<Long, Holder> showBal(String accnum) {
		em.getTransaction().begin();
		TypedQuery<Holder> tq = em.createQuery("select c from Holder c where c.accountnum= :ac", Holder.class);
        tq.setParameter("ac", Long.parseLong(accnum));
        tq.getSingleResult();
		Holder c= tq.getSingleResult(); 
		em.getTransaction().commit();
		System.out.println(c.getMoney());
		return accmap;
	}

	@Override
	public void deposit(String acnum,double amt) {
	
//		Holder s2=em.find(Holder.class, c.getAccountnum());
//        em.getTransaction().begin();
//        s2.setMoney(c.getMoney());
//        em.merge(s2);
//        em.getTransaction().commit();
		em.getTransaction().begin();
		TypedQuery<Holder> tq = em.createQuery("select c from Holder c where c.accountnum= :ac", Holder.class);
        tq.setParameter("ac", Long.parseLong(acnum));
     
        double bal = tq.getSingleResult().getMoney();
        
        tq = em.createQuery("update Holder c set c.money = :x where c.accountnum= :ac", Holder.class);
        tq.setParameter("x", bal+amt);
        tq.setParameter("ac", Long.parseLong(acnum));
    
        int i=tq.executeUpdate();
       
        em.getTransaction().commit();
        System.out.println("The balance is :"+(bal+amt));
	}

	@Override
	public void withdraw(String accnum1,double amt1) {
//		Holder s2=em.find(Holder.class, c.getAccountnum());
//        em.getTransaction().begin();
//        s2.setMoney(c.getMoney());
//        em.merge(s2);
//        em.getTransaction().commit();
        
        System.out.println(accnum1);
		TypedQuery<Holder> tq = em.createQuery("select c from Holder c where c.accountnum= :ac", Holder.class);
        tq.setParameter("ac", Long.parseLong(accnum1));
     
        double bal = tq.getSingleResult().getMoney();
        em.getTransaction().begin();
        tq = em.createQuery("update Holder c set c.money = :x where c.accountnum= :ac", Holder.class);
        tq.setParameter("x", bal-amt1);
        tq.setParameter("ac", Long.parseLong(accnum1));
    
        int i=tq.executeUpdate();
        System.out.println(i);
        em.getTransaction().commit();
        System.out.println("The balance is :"+(bal-amt1));
		
	}

	@Override
	public double transfer(String yaccnum, String raccnum, double amt) throws IOException {
		
		em.getTransaction().begin();
		TypedQuery<Holder> cust =em.createQuery("SELECT c FROM Holder c WHERE c.accountnum= :ac", Holder.class);
		cust.setParameter("ac", Long.parseLong(yaccnum));
		Holder c = cust.getSingleResult();
		double accbal=c.getMoney();

		TypedQuery<Holder> cust1=em.createQuery("SELECT c FROM Holder c WHERE c.accountnum= :ac", Holder.class);
		cust1.setParameter("ac", Long.parseLong(raccnum));
		Holder c1 = cust1.getSingleResult();
		double r_accbal = c1.getMoney();
		
		cust=em.createQuery("UPDATE Holder c SET c.money = :money WHERE c.accountnum= :ac", Holder.class);
		cust.setParameter("money", accbal-amt );
		cust.setParameter("ac", Long.parseLong(yaccnum));
		cust.executeUpdate();
		
		cust1=em.createQuery("UPDATE Holder c1 SET c1.money = :money WHERE c1.accountnum= :raccnum", Holder.class);
		cust1.setParameter("money", r_accbal+amt);
		cust1.setParameter("raccnum", Long.parseLong(raccnum));
		cust1.executeUpdate();
		em.getTransaction().commit();
		return accbal-amt;
	}

}
