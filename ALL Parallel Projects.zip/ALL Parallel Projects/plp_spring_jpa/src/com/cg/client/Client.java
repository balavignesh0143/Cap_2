package com.cg.client;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.beans.Account;
import com.cg.beans.Customer;
import com.cg.beans.Transaction;
import com.cg.exception.WalletException;
import com.cg.service.IWalletService;
import com.cg.service.WalletServiceImpl;

/***
 * 
 * @author shesahu
 *
 */
@Configuration
@ComponentScan("com.*")
public class Client {
	@Autowired
	static IWalletService iWalletService;
	static Customer customer;
	public static void main(String[] args) {
	
		Scanner scanner = new Scanner(System.in);
		Scanner scanner2 = new Scanner(System.in);
		String choice = null;
		String choice2 = null;

		do {
			System.out.println("1.Create Account\n2.Login\n3.View All Customer");
			int option = scanner.nextInt();
			switch (option) {
			case 1: {

				try {
					System.out.println("Create Account:");
					System.out.println("Enter Customer Name:");
					String customerName = scanner2.nextLine();
					System.out.println("Enter date of birth");
					String dateOfBirth = scanner.next();
					System.out.println("Enter Mobile Number");
					String phone = scanner.next();
					try {
						if (phone.length() != 10) {
							throw new WalletException();
						}
					} catch (Exception e2) {
						System.out.println("Please enter 10 digits mobile number:");
					}
					System.out.println("Enter Email");
					String email = scanner.next();
					/*
					 * try { if(!walletService.validateEmail(email)) { throw new WalletException();
					 * } } catch (Exception e1) { System.out.
					 * println("Please enter correct email address which contains alphabets,number and special symbol"
					 * ); }
					 */
					System.out.println("Enter Address");
					String address = scanner2.nextLine();
					double balance = 0.0;
					Account account = new Account(balance);
					Customer customer = new Customer(customerName, dateOfBirth, phone, email, address, account, null);
					Customer createdCustomer = iWalletService.createAccount(customer);
					System.out.println("Account created successfully....");
					int customId = customer.getCustomerId();
					System.out.println("Customer Id is " + customId);
					System.out.println("Account No. is " + account.getAccountNo());
					do {
						System.out.println(
								"1.Show Balance\n2.Deposit Money\n3.Withdraw Money\n4.Fundtransfer\n5.Print Transaction\n6.Exit");
						int option2 = scanner.nextInt();

						switch (option2) {
						case 1: {

							try {
								System.out.println("Your balance is " + iWalletService.showBalance(customId));
							} catch (WalletException e) {
							}

						}
							break;
						case 2: {

							System.out.println("Enter Amount To Deposit");
							double amount = scanner.nextDouble();
							try {
								if (iWalletService.deposit(customId, amount))
									System.out.println("Amount Deposit Successful....");
								else
									System.out.println("Error Occured");
							} catch (WalletException e) {
							}
						}
							break;
						case 3: {

							System.out.println("Enter Amount To Withdraw");
							double amount = scanner.nextDouble();
							try {
								if (iWalletService.withdraw(customId, amount))
									System.out.println("Amount Withdraw Successful!");
								else
									System.out.println("Error Occured");
							} catch (WalletException e) {
							}

						}
							break;
						case 4: {

							System.out.println("Enter Benificiary CustomerId");
							int custId = scanner.nextInt();
							System.out.println("Enter Amount You Want To Transfer");
							double amount = scanner.nextDouble();
							try {
								if (iWalletService.fundTransfer(customId, custId, amount))
									System.out.println("Amount transfered successfully..");
								else
									System.out.println("Error Occured");
							} catch (WalletException e) {
							}
						}
							break;
						case 5: {
							List<Customer> customerList = iWalletService.viewAll();
							for (Customer customer1 : customerList) {
								System.out.println(customer1);
							}
							try {
								List<Transaction> transactionList = iWalletService.printTransaction(customId);
								for (Transaction transaction : transactionList) {
									if (transaction.getTransactionType().equals("Ft"))
										System.out.println("Amount " + transaction.getAmount() + " "
												+ transaction.getTransactionType() + " to customerId "
												+ customer.getCustomerId() + " transaction date is "
												+ transaction.getTransactionDate());
									else
										System.out.println("Amount " + transaction.getAmount() + " "
												+ transaction.getTransactionType() + " to transactionId "
												+ transaction.getTransactionId() + " transaction date is "
												+ transaction.getTransactionDate());
								}
							} catch (WalletException e) {
							}
						}
							break;

						case 6: {
							System.out.println("Thank You!");
							System.exit(0);
						}
							break;
						default: {
							System.out.println("Enter correct choice:");
						}
							break;
						}
						System.out.println("Press 'y' to continue........");
						choice = scanner.next();
					} while (choice.equalsIgnoreCase("y"));

				} catch (WalletException e) {
					e.printStackTrace();
				}

			}
				break;

			case 2: {
				System.out.println("Enter Cutsomer ID");
				int customerId = scanner.nextInt();

				do {
					System.out.println(
							"1.Show Balance\n2.Deposit Money\n3.Withdraw Money\n4.Fundtransfer\n5.Print Transaction\n6.Exit");
					int option2 = scanner.nextInt();

					switch (option2) {
					case 1: {

						try {
							System.out.println("Your balance is " + iWalletService.showBalance(customerId));
						} catch (WalletException e) {
						}

					}
						break;
					case 2: {

						System.out.println("Enter Amount To Deposit");
						double amount = scanner.nextDouble();
						try {
							if (iWalletService.deposit(customerId, amount))
								System.out.println("Amount Deposit Successful....");
							else
								System.out.println("Error Occured");
						} catch (WalletException e) {
						}
					}
						break;
					case 3: {

						System.out.println("Enter Amount To Withdraw");
						double amount = scanner.nextDouble();
						try {
							if (iWalletService.withdraw(customerId, amount))
								System.out.println("Amount Withdraw Successful!");
							else
								System.out.println("Error Occured");
						} catch (WalletException e) {
						}

					}
						break;
					case 4: {

						System.out.println("Enter Benificiary CustomerId");
						int custId = scanner.nextInt();
						System.out.println("Enter Amount You Want To Transfer");
						double amount = scanner.nextDouble();
						try {
							if (iWalletService.fundTransfer(customerId, custId, amount))
								System.out.println("Amount transfered successfully..");
							else
								System.out.println("Error Occured");
						} catch (WalletException e) {
						}
					}
						break;
					case 5: {
						List<Customer> customerList = new ArrayList<Customer>();
						customerList=	iWalletService.viewAll();
						System.out.println("main"+customerId);
						for (Customer customer1 : customerList) {
							System.out.println(customer1);
						}

						try {
							List<Transaction> transactionList = iWalletService.printTransaction(customerId);
							for (Transaction transaction : transactionList) {
								if (transaction.getTransactionType().equals("Ft"))
									System.out.println(
											"Amount " + transaction.getAmount() + " " + transaction.getTransactionType()
													+ " to customerId " + customer.getCustomerId()
													+ " transaction date is " + transaction.getTransactionDate());
								else
									System.out.println(
											"Amount " + transaction.getAmount() + " " + transaction.getTransactionType()
													+ " to transactionId " + transaction.getTransactionId()
													+ " transaction date is " + transaction.getTransactionDate());
							}
						} catch (WalletException e) {
						}

					}
						break;

					case 6: {
						System.out.println("Thank You!");
						System.exit(0);
					}
						break;
					default: {
						System.out.println("Enter correct choice:");
					}
						break;
					}
					System.out.println("Press 'y' to continue........");
					choice = scanner.next();
				} while (choice.equalsIgnoreCase("y"));
			}
				break;
			case 3: {
				System.out.println("View All Customer");
				List<Customer> customerList = iWalletService.viewAll();
				for (Customer customer1 : customerList) {
					System.out.println(customer1);
				}
			}
				break;
			default: {
				System.out.println("Enter Correct Choice..");
			}
				break;
			}
			System.out.println("press 'z' to continue...");
			choice2 = scanner.next();
		} while (choice2.equalsIgnoreCase("z"));
		scanner.close();
		scanner2.close();
	}
}
