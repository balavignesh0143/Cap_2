package com.cg.beans;
/***
 * @author shesahu
 */
import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
@Entity
@Table(name="Wallet_Transaction_spring_jpa")
@Component
public class Transaction implements Serializable {
	
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "myseq")
	@SequenceGenerator(name = "myseq",sequenceName = "transactionsequencespringjpa",allocationSize = 1,initialValue = 900)
	@Column(length = 5)
	private int transactionId;
	@Column(length = 10)
	private String transactionType;
	@Column(length = 10)
	private Date transactionDate;
	@Column(length = 15)
	private long toAccountNo;
	@Column(precision = 10,scale = 2,length = 12)
	private Double amount;
	@ManyToOne(cascade = CascadeType.ALL)
	@Autowired
	private Customer customer;
	public Transaction() {
		super();
	}
	public Transaction(int transactionId, String transactionType, Date transactionDate, long toAccountNo, Double amount) {
		super();
		this.transactionId = transactionId;
		this.transactionType = transactionType;
		this.transactionDate = transactionDate;
		this.toAccountNo = toAccountNo;
		this.amount = amount;
	}
	public Transaction(String transactionType, Date transactionDate, long toAccountNo, Double amount) {
		super();
		this.transactionType = transactionType;
		this.transactionDate = transactionDate;
		this.toAccountNo = toAccountNo;
		this.amount = amount;
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public Date getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}
	public long getToAccountNo() {
		return toAccountNo;
	}
	public void setToAccountNo(long toAccountNo) {
		this.toAccountNo = toAccountNo;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	
	
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	@Override
	public String toString() {
		return "\ntransactionId=" + transactionId + ", transactionType=" + transactionType
				+ ", transactionDate=" + transactionDate + ", toAccountNo=" + toAccountNo	+ ", amount=" + amount;
	}

}
