package com.cg.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.cg.beans.Account;
import com.cg.beans.Customer;
import com.cg.beans.Transaction;
import com.cg.exception.WalletException;

/***
 * 
 * @author shesahu
 *
 */
@Repository
public class WalletDaoImpl implements IWalletDao {
	EntityManagerFactory entityManagerFactory;
	@PersistenceContext
	EntityManager entityManager;
	
	/**
	 * This method we will use to create account
	 */
	@Transactional
	public Customer createAccount(Customer customer) {
		entityManager.persist(customer);
		return customer;
	}

	List<Transaction> transactionList = new ArrayList<Transaction>();
	/**
	 * This method will show the balance of the customer
	 */
	public double showBalance(int customerId) throws WalletException {

		Customer customer;
		try {
			customer = entityManager.find(Customer.class, customerId);
		} catch (Exception e) {
			throw new WalletException("invalid reciver id");
		}
		return customer.getAccount().getBalance();

	}
	/**
	 * This method we will use to Deposit the money the account
	 */
	public boolean deposit(int customerId, double amount) throws WalletException {
		Date transactionDate = new Date();
		Customer customer;
		try {
			customer = entityManager.find(Customer.class, customerId);
		} catch (Exception e) {
			throw new WalletException("invalid reciver id");
		}
		double balance = customer.getAccount().getBalance() + amount;
		Account account = customer.getAccount();
		account.setBalance(balance);
		customer.setAccount(account);
		Transaction transaction = new Transaction("Deposit", transactionDate, 0, amount);
		transaction.setCustomer(customer);
		transactionList.add(transaction);
		customer.setTransactionList(transactionList);
		entityManager.merge(customer);
		return true;
	}
	/**
	 * This method we will use to withdraw the money the account
	 */

	public boolean withdraw(int customerId, double amount) throws WalletException {
		boolean result;
		Date transactionDate = new Date();
		Customer customer;
		try {
			customer = entityManager.find(Customer.class, customerId);
		} catch (Exception e) {
			throw new WalletException("invalid reciver id");
		}
		if (customer.getAccount().getBalance() < amount) {
			throw new WalletException("Insufficient Balance");
		} else {
			double balance = customer.getAccount().getBalance() - amount;
			Account account = customer.getAccount();
			account.setBalance(balance);
			customer.setAccount(account);
			Transaction transaction = new Transaction("Withdraw", transactionDate, 0, amount);
			transaction.setCustomer(customer);
			transactionList.add(transaction);
			customer.setTransactionList(transactionList);
			entityManager.merge(customer);
			result = true;
		}
		return result;

	}
	/**
	 * This method we wiil use for transafer the money from one account to another inbuilt account
	 */

	public boolean fundTransfer(int senderId, int recieverId, double amount) throws WalletException {
		Date transactionDate = new Date();

		Customer receiverCustomer;
		try {
			receiverCustomer = entityManager.find(Customer.class, recieverId);
		} catch (Exception e) {
			throw new WalletException("invalid reciver id");
		}
		Customer senderCustomer = entityManager.find(Customer.class, senderId);

		boolean result;

		if (senderCustomer.getAccount().getBalance() < amount) {
			return false;
		} else {
			Account receiverAccount = receiverCustomer.getAccount();
			double receiverBalance = receiverAccount.getBalance();
			receiverBalance = receiverAccount.getBalance() + amount;
			receiverAccount.setBalance(receiverBalance);
			receiverCustomer.setAccount(receiverAccount);

			Account senderAccount = senderCustomer.getAccount();
			double senderBalance = senderAccount.getBalance();
			senderBalance = senderAccount.getBalance() - amount;
			senderAccount.setBalance(senderBalance);
			senderCustomer.setAccount(senderAccount);

			Transaction sendtransaction = new Transaction("Ft", transactionDate, receiverAccount.getAccountNo(),
					amount);
			sendtransaction.setCustomer(senderCustomer);
			List<Transaction> senderTransactionList = new ArrayList<Transaction>();
			senderTransactionList = senderCustomer.getTransactionList();
			senderTransactionList.add(sendtransaction);

			Transaction recievetransaction = new Transaction("Fr", transactionDate, senderAccount.getAccountNo(),
					amount);
			recievetransaction.setCustomer(receiverCustomer);
			List<Transaction> recieveTransactionList = new ArrayList<Transaction>();
			recieveTransactionList = receiverCustomer.getTransactionList();
			recieveTransactionList.add(recievetransaction);

			senderCustomer.setTransactionList(senderTransactionList);
			receiverCustomer.setTransactionList(recieveTransactionList);

			entityManager.merge(receiverCustomer);
			entityManager.merge(senderCustomer);
			result = true;
		}
		return result;

	}

	/**
	 * This method will print the all transactions
	 */
	public List<Transaction> printTransaction(int customerId) {
		System.out.println("dao"+customerId);
		return entityManager.find(Customer.class, customerId).getTransactionList();
	}
	/**
	 * This method we use to print the all account present in this Data base
	 */
	public List<Customer> viewAll() {
		Query query = entityManager.createQuery("from Customer");
		List<Customer> customerList = query.getResultList();
		for (Customer customer : customerList) {
			System.out.println(customer);
		}
		return customerList;

	}
	/**
	 * we will use this method to give the validation for email that should have alphabets, numbers,
	 * special symbol (@,.)
	 */
	public boolean validateEmail(String email) {
		boolean result;
		result = false;
		String emailRegEx = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
				+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
		Pattern pattern = Pattern.compile(emailRegEx);
		Matcher matcher = pattern.matcher(email);
		if (matcher.matches()) {
			result = true;
		}
		return result;
	}


}
