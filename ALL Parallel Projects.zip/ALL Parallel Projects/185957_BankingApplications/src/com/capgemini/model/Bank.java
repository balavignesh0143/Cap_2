package com.capgemini.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Bank {
	private String userName;
	private String password;
	private  int accNo;
	private  int balance;
	private static int accno=1004;
	private List<String> list = new ArrayList<String>();
	
	/*
	 * Constructor to enter the static details to access collections
	 * 
	 */
	
	public List<String> getList() {
		return list;
	}

	public void setList(String s) {
		list.add(s);
		this.list = list;
	}

	public Bank(String userName, String password, int accNo, int balance) {
		super();
		this.userName = userName;
		this.password = password;
		this.accNo = accNo;
		this.balance = balance;
	}
	
	/*
	 * Password setup
	 */
	private Scanner sc = new Scanner(System.in);

	public String getPassword() {
		return password;
	}

	public void setPassword() {
		System.out.println("Set Password");
		password=sc.next();
	}
	
	
	/*
	 * Object print setup
	 */
	@Override
	public String toString() {
		return "Bank [userName=" + userName + ", accNo=" + accNo + ", balance="
				+ balance + "]";
	}
	/*
	 * UseName Validation As First letter capital
	 */
	public String getUserName() {
		return userName;
	}
	public int setUserName(String userName) {
		if(userName.charAt(0)>65 && userName.charAt(0)<90 ){
			this.userName=userName;
			return 0;
			}
		else
		{
			System.out.println("Enter first letter as capital");
		}
		return 1;
	}
	/*
	 * Account no. getters and setters and generating account no. for new Account
	 */
	
	public int getAccNo() {
		return accNo;
	}
	public void setAccNo() {
		 accNo=++accno;
	}
	public Bank() {
		super();
	}
	
	public  int getBalance() {
		return balance;
	}
	public  void setBalance(int balance) {
		this.balance = balance;
	}
	public void setBalance()
	{
		balance=0;
	}

	

}
