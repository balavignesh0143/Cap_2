package com.capgemini.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import com.capgemini.bean.Holder;
import com.capgemini.dao.DAO;
import com.capgemini.dao.DAOImpl;
import com.capgemini.validation.Validators;

public class ServiceImpl implements Service {
	
	DAO dao = new DAOImpl();
	Validators val = new Validators();

	@Override
	public Holder saveCustomer(Holder c) {
		
		return dao.addAccount(c);
		
	}

	@Override
	public Map<Long, Holder> showBalance(String accnum) {
		
			return dao.showBal(accnum);
	}

	@Override
	public void depositAmount(String acnum,double amt) {
		
		
			dao.deposit(acnum, amt);
		
	}

	@Override
	public void withdrawAmount(String accnum1,double amt1) {
		
		Holder c = new Holder();
		double new_balance= (c.getMoney())-amt1;
		if(new_balance<1000 ||  (amt1)<0)
		{
			new_balance= c.getMoney();
		}
			dao.withdraw(accnum1, amt1);
		
	}

	@Override
	public double fundTransfer(String yaccnum, String raccnum, double amt) throws IOException {
			return dao.transfer(yaccnum,raccnum, amt);
	}

	@Override
	public ArrayList<String> printTransaction(String acc_num) {
		// TODO Auto-generated method stub
		return null;
	}

}
