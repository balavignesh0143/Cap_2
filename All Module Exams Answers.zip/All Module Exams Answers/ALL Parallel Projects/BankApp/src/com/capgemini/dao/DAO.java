package com.capgemini.dao;

import java.io.IOException;
import java.util.Map;

import com.capgemini.bean.Holder;

public interface DAO {

	Holder addAccount(Holder c);

	Map<Long, Holder> showBal(String accnum);

	void deposit(String acnum,double amt);

	void withdraw(String accnum1,double amt1);

	double transfer(String yaccnum, String raccnum, double amt) throws IOException;

}
