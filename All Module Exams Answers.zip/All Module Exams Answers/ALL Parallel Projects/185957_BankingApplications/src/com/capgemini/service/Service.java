package com.capgemini.service;

import java.util.List;

import com.capgemini.model.Bank;

public interface Service {

	void createAccount();

	Bank showBalance();

	void deposit();

	void withDraw();

	void fundTransfer();

	List<String> printTrans();

}
