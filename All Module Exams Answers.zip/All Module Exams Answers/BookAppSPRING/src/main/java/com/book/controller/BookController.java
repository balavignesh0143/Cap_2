package com.book.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.book.bean.Book;
import com.book.exception.BookException;
import com.book.service.BookService;

@RestController
public class BookController {
	@Autowired
	BookService bookService;
	@RequestMapping("/books")
	public List <Book> getAllBooks() throws BookException
	{
		return bookService.getAllBooks();
	}
	@RequestMapping(value="/book", method=RequestMethod.POST)
	public List<Book> addBook(@RequestBody Book b) throws BookException{
		return bookService.addBook(b);
			}
	
	@RequestMapping("/books/{id}")
	public Book getBookById(@PathVariable int id) throws BookException{
	return bookService.getBookById(id);
}
	
	@RequestMapping("/getBookByAuthor/author")
	public List <Book> getBookByAuthor(@RequestParam String author) throws BookException{
		return bookService.getBookByAuthor(author) ;
	}
	
	
	@DeleteMapping("/books/{id}")	
	public ResponseEntity<String> deleteBook(@PathVariable int id) throws BookException {
	bookService.deleteBook(id);
	return new ResponseEntity<String> ("Book with id "+id+" deleted",HttpStatus.OK);
	}
	
	
	
	@PutMapping("/books/{id}")
	public List <Book> updateBook(@PathVariable int id, @RequestBody Book b) throws BookException{
		return bookService.updateBook(id, b);
	}
	
}