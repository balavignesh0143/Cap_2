package com.cg.capStore.service;

import org.springframework.stereotype.Service;

import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceUnit;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.capStore.bean.Cart;
import com.cg.capStore.bean.Products;
import com.cg.capStore.bean.CapStore;
import com.cg.capStore.bean.CapUser;
import com.cg.capStore.dao.CapStoreDao;
import com.cg.capStore.dao.CartDao;
import com.cg.capStore.dao.ProductsDao;
import com.cg.capStore.dao.UserDao;
import com.cg.capStore.exception.CartException;


@Service
public class CartServiceImpl implements CartService
{
	@Autowired
	CartDao repo;
	
	@Autowired
	ProductsDao prepo;
	
	@Autowired
	UserDao urepo;
	
	@Autowired
	CapStoreDao caprepo;
	
	
	
	@Override
	public List<Cart> viewcartProducts() {
		
		return repo.findAll();
		
	}
	@Override
	public void addToCart(Cart cart) {
		
		repo.save(cart);
	}
	
	@Override
	public List<Cart> deleteFromCart(int id) {
	
		repo.deleteById(id);
		return repo.findAll();
		
	}
	@Override
	public double checkCartTotal() {
		
	 return  repo.getCartSum();
	  
	}
	@Override
	public List<Products> viewProducts() {
		
		return prepo.findAll();
	}
	
	@Override
	public void placeOrder(CapUser user) {
		
		Optional<CapUser> u=urepo.findById(user.getAccountNo());
		
		System.out.println(user.getAccountNo());
		System.out.println(u.isPresent());
		if(u.isPresent())
		{
			CapUser u1=u.get();
			System.out.println(u1.getAccountNo());
			System.out.println(u1.getPin()+" "+user.getPin());
			
			if(u1.getPin().contentEquals(user.getPin()))
			{
				System.out.println(user.getAccountNo()+" "+u1.getAccountNo());
				System.out.println(user.getPin()+" "+u1.getPin());
				double cartValue=checkCartTotal();
				
				double accBal=u1.getAccountBalance();
				System.out.println(cartValue+" "+accBal);

				if(accBal>cartValue)
				{
					u1.setAccountBalance(accBal-cartValue);
					urepo.save(u1);
					updateRevenue(cartValue);
					
				}
			}
		}
	}
	@Override
	
	public void updateRevenue(double amount) {
		double currentRevenue = 0;
		LocalDate d=java.time.LocalDate.now();  
		Date d2=Date.valueOf(d);
		Date r=caprepo.getCapStoreDetails();
		System.out.println(r);
		System.out.println(d2);
	
		
			System.out.println("yes");
			Optional<CapStore> c=caprepo.findById(r);
			if(c.isPresent())
			{
				CapStore c1=c.get();
				currentRevenue=c1.getRevenue();
				if(r.compareTo(d2)==0)
				{
				  c1.setRevenue(currentRevenue+amount);
				  caprepo.save(c1);
				
			    }
				else
				{
					CapStore cap=new CapStore();
					cap.setCapDate(d2);
					cap.setRevenue(currentRevenue+amount);
					caprepo.save(cap);
				}
				
		    }
		
	}

}



