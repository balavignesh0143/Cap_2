package com.cg.capStore.exception;

public class CartException extends Exception {
public CartException()
{
	super();
}
public CartException(String msg)
{
	super(msg);
}
}

