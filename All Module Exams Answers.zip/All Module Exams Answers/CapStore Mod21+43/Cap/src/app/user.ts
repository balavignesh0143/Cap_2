export class User
{
    public  accountNo:String;
	public  pin:String;
	public  accountBalance:number;
	
}