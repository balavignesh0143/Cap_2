package com.capg.service;

import java.util.List;

import com.capg.bean.InvoiceCal;
import com.capg.exception.InvoiceException;

public interface InvoiceService {
	
	

	
	List<InvoiceCal> viewAllInvoice();
	InvoiceCal createInvoice(InvoiceCal obj);
	InvoiceCal updateInvoice(InvoiceCal obj, int id)throws InvoiceException;
	void deleteInvoice(int i) throws InvoiceException;
	InvoiceCal findSingleInvoice(int id)throws InvoiceException;

}
