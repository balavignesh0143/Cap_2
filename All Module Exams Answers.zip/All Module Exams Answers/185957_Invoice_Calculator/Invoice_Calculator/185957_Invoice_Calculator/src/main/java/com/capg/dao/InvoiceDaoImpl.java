package com.capg.dao;


public abstract class InvoiceDaoImpl implements InvoiceDao {

		
	}

	